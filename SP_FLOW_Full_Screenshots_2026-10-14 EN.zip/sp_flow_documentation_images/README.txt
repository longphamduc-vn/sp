TÀI LIỆU HÌNH ẢNH HỆ THỐNG SP-FLOW
Chế độ chụp: Full trang web (Gồm Sidebar + Header + Nội dung)
Thời gian xuất: 11:45:50 14/10/2026

Danh sách hình ảnh chụp theo chức năng:
1. 1. Bàn làm việc (Workspace) -> File: 01_workspace_home.png
2. 2. Tạo yêu cầu mua (Item Request Wizard) -> File: 02_item_request_wizard.png
3. 3. Duyệt kỹ thuật (PIC Review Hub) -> File: 03_pic_review_hub.png
4. 4. Thẩm định ngân sách (Monthly Appraisal) -> File: 04_monthly_appraisal.png
5. 5. Theo dõi đơn hàng (PO Lifecycle) -> File: 05_po_lifecycle.png
6. 6. Quản lý kho & Xuất hàng (Warehouse & WO) -> File: 06_warehouse_hub.png
7. 7. Báo cáo quản trị (Leader Dashboard) -> File: 07_leader_dashboard.png